package baitap;

public class LoaiPhong implements Comparable<LoaiPhong> {
    private String s,name,id,date,fee;
    public LoaiPhong(String s){
        this.s=s;
        this.id=s.trim().split("\\s+")[0];
        this.name=s.trim().split("\\s+")[1];
        this.date=s.trim().split("\\s+")[2];
        this.fee=s.trim().split("\\s+")[3];
    }
    @Override
    public int compareTo(LoaiPhong o) {
        return name.compareTo(o.name);
    }
    @Override
    public String toString(){
        return id+" "+name+" "+date+" "+fee;
    }
    
    
    }
