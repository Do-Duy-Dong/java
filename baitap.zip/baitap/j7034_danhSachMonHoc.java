package baitap;
import java.io.*;
import java.util.*;
public class j7034_danhSachMonHoc {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
            ArrayList<LoaiPhong> ds = new ArrayList<>();
            Scanner in = new Scanner(new File("PHONG.in"));
            int n = Integer.parseInt(in.nextLine());
            while(n-->0){
                ds.add(new LoaiPhong(in.nextLine()));
            }
            Collections.sort(ds);
            for(LoaiPhong tmp : ds){
                System.out.println(tmp);
            }
        }
}
